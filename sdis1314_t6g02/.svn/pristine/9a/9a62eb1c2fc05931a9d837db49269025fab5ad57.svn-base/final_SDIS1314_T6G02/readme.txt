=== Payback Application ===

Important note: The server and web browser client are available online at https://payback-app.herokuapp.com

== Build & Run Instructions ==

Software required: node (http://nodejs.org/), ionic (http://ionicframework.com/), Android SDK (http://developer.android.com/sdk/index.html)

Run server:
    - cd to src/Server
    - node server.js

Run client:
    - cd to src/MobileClient
    - ionic serve

Build mobile application:
    - cd to src/MobileClient
    - cordova build android

Run mobile application:
    - cd to src/MobileClient
    - cordova run android

An .apk that can be installed on Android is provided in bin/Payback-release-unsigned.apk
